public class Main {
    public static void main(String[] args) {
        double a = Math.random();
        double b = Math.random();
        double c = Math.abs(a-b);
        double d = Math.min(a,b);
        double e = Math.max(a,b);
        double f = Math.pow(a,b*10);
        System.out.println(" Первое число - "+ a);
        System.out.println(" Второе число - "+ b);
        System.out.println(" Разница числе взятая по модулю - "+ c);
        System.out.println(" Минимальное из двух значений - "+ d);
        System.out.println(" Максимальное из двух значений - "+ e);
        System.out.println(" Возведение - "+ f);
    }
}
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//Напишите программу, которая получает от пользователя два целых числа и затем вычисляет
// сумму (сложение), разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел.
// Результат вычислений выведите в консоль.

        System.out.println("Введите два целых числа");
        Scanner scan = new Scanner(System.in);
        double a = scan.nextDouble();
        double b = scan.nextDouble();
        double s = a+b;
        double d = a-b;
        double m = a*b;
        double div = a/b;
        double div2 = a%b;
        System.out.printf(" Сумма числе равна %s%n Разница чисел равна %s%n Умножение чисел равно %s%n " +
                "Деление чисел равно %s %s ", s, d, m, div, div2);

    }
}
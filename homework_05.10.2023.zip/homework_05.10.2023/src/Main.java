import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        byte b = (byte) rnd.nextInt();
        short s = (short) rnd.nextInt();
        int i = rnd.nextInt();
        long l = rnd.nextLong();
        float f = rnd.nextFloat();
        double d = rnd.nextDouble();
        char c = (char) rnd.nextInt();
        boolean bool = rnd.nextBoolean();
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
        System.out.println(c);
        System.out.println(bool);

        String text = String.valueOf(i);
        System.out.println(text);

    }
}
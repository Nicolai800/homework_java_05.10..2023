import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
        // Когда все данные введены, программа должна выдать сообщение:
        // «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
        // В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения
        System.out.println("Введите свое имя");
        Scanner scr = new Scanner(System.in);
        String name = scr.nextLine();
        System.out.println("Введите свой возраст (полных лет)");
        int age = scr.nextInt();
        System.out.println("Введите свой вес");
        int weight = scr.nextInt();
        System.out.printf("Уважаемый, %s! В свои %d лет Вы для нас дороги, как %d килограмм золота.", name, age, weight);
    }
}